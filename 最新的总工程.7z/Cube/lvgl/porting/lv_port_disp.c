/**
 * @file lv_port_disp_templ.c
 *
 */

 /*Copy this file as "lv_port_disp.c" and set this value to "1" to enable content*/
#if 1

/*********************
 *      INCLUDES
 *********************/
#include "lv_port_disp.h"
#include "bsp_lcd.h"
#include "dma2d.h"
#include "stm32f4xx_hal_dma.h"
#include "dma.h"
/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/
static void disp_init(void);

static void disp_flush(lv_disp_drv_t * disp_drv, const lv_area_t * area, lv_color_t * color_p);
#if LV_USE_GPU
static void gpu_blend(lv_disp_drv_t * disp_drv, lv_color_t * dest, const lv_color_t * src, uint32_t length, lv_opa_t opa);
static void gpu_fill(lv_disp_drv_t * disp_drv, lv_color_t * dest_buf, lv_coord_t dest_width,
        const lv_area_t * fill_area, lv_color_t color);
#endif

/**********************
 *  STATIC VARIABLES
 **********************/
static __IO uint16_t * my_fb = (__IO uint16_t*) (SDRAM_ADDR);

static DMA_HandleTypeDef  DmaHandle;
static int32_t            x1_flush;
//static int32_t            y1_flush;
static int32_t            x2_flush;
static int32_t            y2_fill;
static int32_t            y_fill_act;
static const lv_color_t * buf_to_flush;
static lv_disp_t *our_disp = NULL;
/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/
#define COLOR_BUF_SIZE (LV_HOR_RES_MAX*LV_VER_RES_MAX)
static lv_color_t draw_buf_1[COLOR_BUF_SIZE]__attribute__((at(SDRAM_ADDR)));
void lv_port_disp_init(void)
{
    /*-------------------------
     * Initialize your display
     * -----------------------*/
    disp_init();

    /*-----------------------------
     * Create a buffer for drawing
     *----------------------------*/

    static lv_disp_buf_t draw_buf_dsc_1;
    lv_disp_buf_init(&draw_buf_dsc_1, draw_buf_1, NULL, COLOR_BUF_SIZE);   /*Initialize the display buffer*/

    /*-----------------------------------
     * Register the display in LVGL
     *----------------------------------*/

    lv_disp_drv_t disp_drv;                         /*Descriptor of a display driver*/
    lv_disp_drv_init(&disp_drv);                    /*Basic initialization*/

    /*Set up the functions to access to your display*/

    /*Set the resolution of the display*/
    disp_drv.hor_res = LV_HOR_RES_MAX;
    disp_drv.ver_res = LV_VER_RES_MAX;

    /*Used to copy the buffer's content to the display*/
    disp_drv.flush_cb = disp_flush;

    /*Set a display buffer*/
    disp_drv.buffer = &draw_buf_dsc_1;

#if LV_USE_GPU
    /*Optionally add functions to access the GPU. (Only in buffered mode, LV_VDB_SIZE != 0)*/

    /*Blend two color array using opacity*/
    disp_drv.gpu_blend_cb = gpu_blend;

    /*Fill a memory array with a color*/
    disp_drv.gpu_fill_cb = gpu_fill;
#endif

    /*Finally register the driver*/
    lv_disp_drv_register(&disp_drv);
}

/**********************
 *   STATIC FUNCTIONS
 **********************/

/* Initialize your display and the required peripherals. */
static void disp_init(void)
{
    /*You code here*/
}

/* Flush the content of the internal buffer the specific area on the display
 * You can use DMA or any hardware acceleration to do this operation in the background but
 * 'lv_disp_flush_ready()' has to be called when finished. */
static void disp_flush(lv_disp_drv_t * disp_drv, const lv_area_t * area, lv_color_t * color_p)
{
    /*The most simple case (but also the slowest) to put all pixels to the screen one-by-one*/
	  int32_t x1 = area->x1;
		int32_t x2 = area->x2;
		int32_t y1 = area->y1;
		int32_t y2 = area->y2;
    printf("x1:%d, y1:%d , x2:%d, y2:%d, w:%d, h:%d\r\n", x1, y1, x2, y2, x2-x1+1, y2-y1+1);
		/*Return if the area is out the screen*/
		if(x2 < 0) return;
		if(y2 < 0) return;
		if(x1 > LV_HOR_RES_MAX - 1) return;
		if(y1 > LV_VER_RES_MAX - 1) return;
		/*Truncate the area to the screen*/
		int32_t act_x1 = x1 < 0 ? 0 : x1;
		int32_t act_y1 = y1 < 0 ? 0 : y1;
		int32_t act_x2 = x2 > LV_HOR_RES_MAX - 1 ? LV_HOR_RES_MAX - 1 : x2;
		int32_t act_y2 = y2 > LV_VER_RES_MAX - 1 ? LV_VER_RES_MAX - 1 : y2;
  
    for(int32_t y = act_y1; y <= act_y2; y++) {
      for(int32_t x = act_x1; x <= act_x2; x++) {
        /* Put a pixel to the display. For example: */
        /* put_px(x, y, *color_p)*/
        my_fb[y*LV_HOR_RES_MAX+x] = (uint32_t)color_p->full;
        color_p++;
      }
    }
//    printf("disp_flush ok\r\n");
    
//	  int32_t x1 = area->x1;
//		int32_t x2 = area->x2;
//		int32_t y1 = area->y1;
//		int32_t y2 = area->y2;
//		/*Return if the area is out the screen*/
//		if(x2 < 0) return;
//		if(y2 < 0) return;
//		if(x1 > LV_HOR_RES_MAX - 1) return;
//		if(y1 > LV_VER_RES_MAX - 1) return;
//		/*Truncate the area to the screen*/
//		int32_t act_x1 = x1 < 0 ? 0 : x1;
//		int32_t act_y1 = y1 < 0 ? 0 : y1;
//		int32_t act_x2 = x2 > LV_HOR_RES_MAX - 1 ? LV_HOR_RES_MAX - 1 : x2;
//		int32_t act_y2 = y2 > LV_VER_RES_MAX - 1 ? LV_VER_RES_MAX - 1 : y2;
//		x1_flush = act_x1;
////		y1_flush = act_y1;
//		x2_flush = act_x2;
//		y2_fill = act_y2;
//		y_fill_act = act_y1;
//		buf_to_flush = color_p;
//		HAL_StatusTypeDef err = HAL_OK;
//		uint32_t length = (x2_flush - x1_flush + 1);
//#if LV_COLOR_DEPTH == 24 || LV_COLOR_DEPTH == 32
//		length *= 2; /* STM32 DMA uses 16-bit chunks so multiply by 2 for 32-bit color */
//#endif
//		err = HAL_DMA2D_Start_IT(&hdma2d, (uint32_t)buf_to_flush, (uint32_t)&my_fb[y_fill_act * LV_HOR_RES_MAX + x1_flush], length, 1);
//		printf("x1:%d ,x2:%d ,y1:%d ,y2:%d , w:%d  h:%d\r\n", x1 ,x2 ,y1, y2, x2-x1+1, y2-y1+1);
//    printf("my_fb: %d, len: %d\r\n", y_fill_act * LV_HOR_RES_MAX + x1_flush, length);
////		err = HAL_DMA_Start_IT(&hdma_memtomem_dma2_stream0,(uint32_t)buf_to_flush, (uint32_t)&my_fb[y_fill_act * LV_HOR_RES_MAX + x1_flush], length);
//		if(err != HAL_OK) {
//			printf("disp_flush Status: %d\r\n",err);
////			while(1);	/*Halt on error*/
//		}else{
//      printf("disp_flush ok\r\n");
//    }
		
    /* IMPORTANT!!!
     * Inform the graphics library that you are ready with the flushing*/
    lv_disp_flush_ready(disp_drv);
}


/*OPTIONAL: GPU INTERFACE*/
#if LV_USE_GPU

/* If your MCU has hardware accelerator (GPU) then you can use it to blend to memories using opacity
 * It can be used only in buffered mode (LV_VDB_SIZE != 0 in lv_conf.h)*/
static void gpu_blend(lv_disp_drv_t * disp_drv, lv_color_t * dest, const lv_color_t * src, uint32_t length, lv_opa_t opa)
{
    /*It's an example code which should be done by your GPU*/
    uint32_t i;
    for(i = 0; i < length; i++) {
        dest[i] = lv_color_mix(dest[i], src[i], opa);
    }
}

/* If your MCU has hardware accelerator (GPU) then you can use it to fill a memory with a color
 * It can be used only in buffered mode (LV_VDB_SIZE != 0 in lv_conf.h)*/
static void gpu_fill(lv_disp_drv_t * disp_drv, lv_color_t * dest_buf, lv_coord_t dest_width,
                    const lv_area_t * fill_area, lv_color_t color)
{
    /*It's an example code which should be done by your GPU*/
    int32_t x, y;
    dest_buf += dest_width * fill_area->y1; /*Go to the first line*/

    for(y = fill_area->y1; y <= fill_area->y2; y++) {
        for(x = fill_area->x1; x <= fill_area->x2; x++) {
            dest_buf[x] = color;
        }
        dest_buf+=dest_width;    /*Go to the next line*/
    }
}

#endif  /*LV_USE_GPU*/

#else /* Enable this file at the top */

/* This dummy typedef exists purely to silence -Wpedantic. */
typedef int keep_pedantic_happy;
#endif
