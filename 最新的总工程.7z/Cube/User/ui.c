#include "ui.h"
#include "../lvgl/lvgl.h"
#include "../lv_conf.h"
#include "../lv_ex_conf.h"
#include "../lvgl/porting/lv_port_disp.h"
#include "cmsis_os.h"
#include <cJSON.h>



static lv_style_t date_style;
static lv_style_t tempe_style;
static lv_style_t weather_style;
static lv_style_t humidity_style;
static lv_style_t speed_style;
static lv_style_t direction_style;
lv_obj_t* weather_screen = NULL;
lv_obj_t* date_label = NULL;
lv_obj_t* tempe_label = NULL;
lv_obj_t* weather_label = NULL;
lv_obj_t* humidity_label = NULL;
lv_obj_t* speed_label = NULL;
lv_obj_t* direction_label = NULL;
void UiInit(void)
{
  weather_screen = lv_obj_create(NULL, NULL);
  lv_style_init(&date_style);
  lv_style_init(&tempe_style);
  lv_style_init(&weather_style);
  lv_style_init(&humidity_style);
  lv_style_init(&speed_style);
  lv_style_init(&direction_style);
  
  // date
  date_label = lv_label_create(weather_screen, NULL);
  lv_label_set_text(date_label, "");
	lv_style_set_text_color(&date_style, LV_STATE_DEFAULT, LV_COLOR_RED);
	lv_style_set_text_font(&date_style, LV_STATE_DEFAULT, &myFont);
  lv_obj_add_style(date_label, LV_OBJ_PART_MAIN, &date_style);

  // tempe
  tempe_label = lv_label_create(weather_screen, NULL);
  lv_label_set_text(tempe_label, "");
	lv_style_set_text_color(&tempe_style, LV_STATE_DEFAULT, LV_COLOR_RED);
	lv_style_set_text_font(&tempe_style, LV_STATE_DEFAULT, &myFont);
  lv_obj_add_style(tempe_label, LV_OBJ_PART_MAIN, &tempe_style);
  
  // weather
  weather_label = lv_label_create(weather_screen, NULL);
  lv_label_set_text(weather_label, "");
  lv_style_set_text_color(&weather_style, LV_STATE_DEFAULT, LV_COLOR_RED);
  lv_style_set_text_font(&weather_style, LV_STATE_DEFAULT, &myFont);
  lv_obj_add_style(weather_label, LV_OBJ_PART_MAIN, &weather_style);
  
  // humidity
  humidity_label = lv_label_create(weather_screen, NULL);
  lv_label_set_text(humidity_label, "");
  lv_style_set_text_color(&humidity_style, LV_STATE_DEFAULT, LV_COLOR_RED);
	lv_style_set_text_font(&humidity_style, LV_STATE_DEFAULT, &myFont);
  lv_obj_add_style(humidity_label, LV_OBJ_PART_MAIN, &humidity_style);
  
  // speed
  speed_label = lv_label_create(weather_screen, NULL);
  lv_label_set_text(speed_label, "");
  lv_style_set_text_color(&speed_style, LV_STATE_DEFAULT, LV_COLOR_RED);
	lv_style_set_text_font(&speed_style, LV_STATE_DEFAULT, &myFont);
  lv_obj_add_style(speed_label, LV_OBJ_PART_MAIN, &speed_style);
  
  // direction
  direction_label = lv_label_create(weather_screen, NULL);
  lv_label_set_text(direction_label, "");
  lv_style_set_text_color(&direction_style, LV_STATE_DEFAULT, LV_COLOR_RED);
  lv_style_set_text_font(&direction_style, LV_STATE_DEFAULT, &myFont);
  lv_obj_add_style(direction_label, LV_OBJ_PART_MAIN, &direction_style);
}

//LV_FONT_DECLARE(myFont)
void UiTest(void) 
{
  static lv_style_t temp_style;
  lv_style_init(&temp_style);
  lv_obj_t* date_label2 = lv_label_create(lv_scr_act(), NULL);
  lv_label_set_text(date_label2, "加载中...");
  lv_style_set_text_color(&temp_style, LV_STATE_DEFAULT, LV_COLOR_RED);
  lv_style_set_text_font(&temp_style, LV_STATE_DEFAULT, &myFont);
  lv_obj_add_style(date_label2, LV_OBJ_PART_MAIN, &temp_style);
  lv_obj_align(date_label2, NULL, LV_ALIGN_CENTER, 10, 10);
}


void UiWeather(WEATHERJSON* w)
{
  if(weather_screen != lv_scr_act()) {
    printf("load weather_screen\r\n");
    lv_scr_load(weather_screen);
  }
  // 日期
  lv_label_set_text(date_label, (char*)w->date);
  lv_obj_set_pos(date_label, 0, 0);
  
  // 气温
  lv_label_set_text(tempe_label, (char*)w->tempe);
  lv_obj_set_pos(tempe_label, 0, 50);
  
  // 天气
  lv_label_set_text(weather_label, (char*)w->weather);
  lv_obj_set_pos(weather_label, 0, 100);

  
  
  // 湿度
  lv_label_set_text(humidity_label, (char*)w->hum);
  lv_obj_set_pos(humidity_label, 0, 150);
  
  // 风速
  lv_label_set_text(speed_label, (char*)w->speed);
  lv_obj_set_pos(speed_label, 0, 200);
  
  // 风向
  lv_label_set_text(direction_label, (char*)w->dir);
  lv_obj_set_pos(direction_label, 0, 250);
}




