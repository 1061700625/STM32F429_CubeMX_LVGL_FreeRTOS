#ifndef __WEATHER_H
#define __WEATHER_H
#include "stm32f4xx_hal.h"

typedef struct {
  uint8_t* date[12];
  uint8_t* weather[32];
  uint8_t* tempe[10];
  uint8_t* speed[4];
  uint8_t* dir[24];
  uint8_t* hum[4];
}WEATHERJSON;


void getWeather(void);
void getTimestamp(void);
void SendToUart3(uint8_t* buff);
void parseWeatherJson(char* buff);
void parseTimestampJson(char* buff);





#endif


