#include "weather.h"
#include "usart.h"
#include <cJSON.h>
#include "ui.h"
#include <task.h>
#include "cmsis_os.h"
#include <string.h>

void getWeather(void)
{
	HAL_UART_Transmit(&huart3, (uint8_t*)"weather", 7, 0XFF);
}
void getTimestamp(void)
{
	HAL_UART_Transmit(&huart3, (uint8_t*)"timestamp", 9, 0XFF);
}
void SendToUart3(uint8_t* buff)
{
	HAL_UART_Transmit(&huart3, buff, strlen((char*)buff), 0XFF);
}
  

WEATHERJSON weather_json = {0};

#include "gbk_utf8_unicode.h"
#include <string.h>
#include <stdio.h>
#include "../lvgl/lvgl.h"
void parseWeatherJson(char* buff)
{ 
	cJSON* root = cJSON_Parse(buff);
	if (!root) {
		printf("root error: %s\r\n", cJSON_Print(root));
    return;
	}
	cJSON* results = cJSON_GetObjectItem(root, "results");
  cJSON* result = cJSON_GetArrayItem(results, 0);
	cJSON* daily = cJSON_GetObjectItem(result, "daily");			

  int array_cnt = cJSON_GetArraySize(daily);
  printf("array_cnt = %d\r\n", array_cnt);

  array_cnt = 1;
	for (int i = 0; i < array_cnt; i++)
	{
    cJSON* item = cJSON_GetArrayItem(daily, i);
    cJSON* date = cJSON_GetObjectItem(item, "date");
    cJSON* text_day = cJSON_GetObjectItem(item, "text_day");
    cJSON* text_night = cJSON_GetObjectItem(item, "text_night");		
    cJSON* high = cJSON_GetObjectItem(item, "high");		
    cJSON* low = cJSON_GetObjectItem(item, "low");
    cJSON* wind_speed = cJSON_GetObjectItem(item, "wind_speed");
    cJSON* humidity = cJSON_GetObjectItem(item, "humidity");
    cJSON* wind_direction = cJSON_GetObjectItem(item, "wind_direction");
    
    printf("\r\n***************\r\n");
		printf("date:   %s\r\n", date->valuestring);
		printf("day:    %s\r\n", text_day->valuestring);
		printf("night:  %s\r\n", text_night->valuestring);
		printf("high:   %s\r\n", high->valuestring);
		printf("low:    %s\r\n", low->valuestring);
    printf("humi:   %s\r\n", humidity->valuestring);
		printf("speed:  %s\r\n", wind_speed->valuestring);
    printf("dire:   %s\r\n", wind_direction->valuestring);
    printf("***************\r\n");
    
    sprintf((char*)weather_json.date,     "%s", date->valuestring);
    sprintf((char*)weather_json.weather,  "%s ~ %s", text_day->valuestring, text_night->valuestring);
    sprintf((char*)weather_json.tempe,    "%s ~ %s C", low->valuestring, high->valuestring);
    sprintf((char*)weather_json.hum,      "%s%%", humidity->valuestring);
    sprintf((char*)weather_json.dir,      "%s", wind_direction->valuestring);
    sprintf((char*)weather_json.speed,    "%s", wind_speed->valuestring);
    
    UiWeather(&weather_json);
    cJSON_Delete(root);
	}
}


void parseTimestampJson(char* buff) 
{
  cJSON* root = cJSON_Parse(buff);
	if (!root) {
		printf("root error: %s\r\n", cJSON_Print(root));
    return;
	}
  cJSON* data = cJSON_GetObjectItem(root, "data");
	cJSON* gmt = cJSON_GetObjectItem(data, "gmt");
  printf("gmt: %s\r\n", gmt->valuestring);
  UiTimestamp(gmt->valuestring);
  cJSON_Delete(root);
}















