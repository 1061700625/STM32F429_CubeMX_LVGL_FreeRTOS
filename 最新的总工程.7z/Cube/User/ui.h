#ifndef __UI_H
#define __UI_H
#include "stm32f4xx_hal.h"
#include <freertos.h>
#include <queue.h>
#include "weather.h"



void UiInit(void);
void UiWeather(WEATHERJSON* w);

void UiTest(void);





#endif


